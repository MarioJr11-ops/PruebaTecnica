DROP DATABASE IF EXISTS `sigec_db` ;
CREATE DATABASE IF NOT EXISTS `sigec_db` ;
USE `sigec_db` ;


-- Tabla Pacientes
DROP TABLE IF EXISTS `Pacientes` ;
CREATE TABLE `Pacientes` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
`nombre` VARCHAR(100) NOT NULL,
`apellido` VARCHAR(100) NOT NULL ,
`fecha_nacimiento` DATE NOT NULL ,  
`genero` VARCHAR(3) NOT NULL,
`numero_identificacion` VARCHAR(100) NOT NULL
 
);


INSERT INTO Pacientes (
    nombre,
    apellido,
    fecha_nacimiento,
    genero,
    numero_identificacion
) VALUES (
    'Juan',
    'Pérez',
    '1990-05-15',
    'M',
    '1234567890'
);



