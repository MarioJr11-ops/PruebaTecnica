DELIMITER $$

CREATE PROCEDURE InsertarPaciente (
    IN p_nombre VARCHAR(100),
    IN p_apellido VARCHAR(100),
    IN p_fecha_nacimiento DATE,
    IN p_genero VARCHAR(3),
    IN p_numero_identificacion VARCHAR(100)
)
BEGIN



    INSERT INTO Pacientes (
        nombre,
        apellido,
        fecha_nacimiento,
        genero,
        numero_identificacion
    ) VALUES (
        p_nombre,
        p_apellido,
        p_fecha_nacimiento,
        p_genero,
        p_numero_identificacion
    );
    
    
END$$

DELIMITER ;