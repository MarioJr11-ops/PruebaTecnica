
DELIMITER $$

CREATE PROCEDURE ObtenerPacientes()

BEGIN


    SELECT * FROM Pacientes;
    
    
    
END$$

DELIMITER ;
